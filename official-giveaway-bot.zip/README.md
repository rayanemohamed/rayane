# 🎁 Official-Giveaways-Bot ⚡
GiveawaysBot allowa you to conduct giveaways in your discord server with lightning fast speed. 

## Directly run the code on repl.it
[![Run on Repl.it](https://repl.it/badge/github/Zaid-maker/official-giveaway-bot)](https://repl.it/github/Zaid-maker/official-giveaway-bot)

# Status 
[![Discord Bots](https://top.gg/api/widget/status/606587080042086420.svg)](https://top.gg/bot/606587080042086420)
[![Discord Bots](https://top.gg/api/widget/servers/606587080042086420.svg)](https://top.gg/bot/606587080042086420)
[![Discord Bots](https://top.gg/api/widget/upvotes/606587080042086420.svg)](https://top.gg/bot/606587080042086420)

# Links
- 🔗 [Invite Link](https://discordapp.com/api/oauth2/authorize?client_id=606587080042086420&permissions=8&scope=bot)
- 😎 [Support Server Link](https://discord.gg/wjBJJUY)
- 📃 [Commands](https://github.com/Zaid-maker/-Official-Giveaway-Bot-/blob/master/AVAILABLE_COMMANDS.md)

# Copyright 
Copyright 2020 © All RIghts are Reserved | If you are using any part of code please give me credits. Thanks
